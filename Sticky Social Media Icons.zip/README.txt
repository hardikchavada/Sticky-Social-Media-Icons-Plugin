=== Sticky Social Media Icons ===
Contributors: hardikchavada
Donate link: https://testhardik.ml/about/
Tags: Social media icons, sticky icons, socialmedia floating icons, floating icons
Requires at least: 4.7
Tested up to: 5.8
Stable tag: 1.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add Sticky Social Media Icons to your WordPress Website with one click.

== Description ==

Easy installation one-click plugin for your WordPress website. You can place your social media url's inside the plugin page.

Sticky Social Media Icons features
- Easy installation
- Social Media Icons to your Page / Posts
- No Coding required

A few notes about the sections above:



== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `sticky-social-media-icons.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Open Sticky Icons page in the WordPress dashboard
4. Add your Social Media Links

== Frequently Asked Questions ==

= Are there any extra settings? =
Currently there are not extra settings for this version. Add your links inside the Sticky Icons page inside WordPress dashboard

= Are there translations? =
Not yet.


== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png



== Changelog ==
= 1.5 =
* Added Telegram Social Media Icon

= 1.3 =
* Added new features

= 1.1 =
* Fixed icons displaying issue

= 1.0 =
* A easy installation plugin to add your social media links to your WordPress website


== Upgrade Notice ==

= 1.6 =
Future Updates will have more Social Links and design features.

